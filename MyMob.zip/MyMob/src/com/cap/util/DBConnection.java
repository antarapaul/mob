package com.cap.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

import com.cap.exception.MobilePurchaseException;

public class DBConnection {

	private static Connection connection = null;
	private static DBConnection instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;

	public DBConnection() throws MobilePurchaseException {
		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			throw new MobilePurchaseException(
					" Could not read the database details from properties file ");
		} catch (SQLException e) {
			throw new MobilePurchaseException(e.getMessage());
		}

	}


	public static DBConnection getInstance() throws MobilePurchaseException {
		synchronized (DBConnection.class) {
			if (instance == null) {
				instance = new DBConnection();
			}
		}
		return instance;
	}

	/*public static Connection getConnection() throws MobilePurchaseException, SQLException{
			if(connection==null){
				if(instance==null){
					instance=new DBConnection();
				}
				return dataSource.getConnection();
			}
			return connection;
		}*/
	//using synchronization
	public static Connection getConnection() throws MobilePurchaseException, SQLException{
		if(connection==null){
			getInstance();
			return dataSource.getConnection();
		}
		return connection;
	}	




	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "resources/database.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	private OracleDataSource prepareDataSource() throws SQLException {

		if( dataSource == null) {
			//Properties properties = null;
			if (props != null) {
				String connectionURL =props.getProperty("url");
				String username =props.getProperty("username");
				String password = props.getProperty("password");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}

}
