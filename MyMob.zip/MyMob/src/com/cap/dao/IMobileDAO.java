package com.cap.dao;

import java.util.List;

import com.cap.bean.Mobile;
import com.cap.exception.MobilePurchaseException;

public interface IMobileDAO {
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException;
	public Boolean isValidMobileId(Integer mobileId) throws MobilePurchaseException;

}
