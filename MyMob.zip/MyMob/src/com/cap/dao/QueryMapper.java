package com.cap.dao;

public interface QueryMapper {
	public static final String RETRIEVE_ALL_MOBILES="SELECT  * FROM mobiles";
	public static final String IS_VALID_MOBILE_ID="SELECT * From mobiles where mobileid=?";
	public static final String ADD_PURCHASE_DETAILS="INSERT INTO purchasedetails VALUES(purchaseid_sequence.NEXTVAL,?,?,?,sysdate,?)";
	public static final String PURCHASE_ID="SELECT purchaseid_sequence.CURRVAL FROM DUAL";
	public static final String UPDATE_MOBILE_QUANTITY="UPDATE mobiles SET quantity-? WHERE mobileid=?";
	public static final String GET_VALID_MOBILE_ID = "SELECT * FROM mobiles WHERE mobileid=?";
	
	

}
