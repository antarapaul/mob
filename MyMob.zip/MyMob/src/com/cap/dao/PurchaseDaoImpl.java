package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cap.exception.MobilePurchaseException;
import com.cap.util.DBConnection;

public class PurchaseDaoImpl implements IPurchaseDAO{

	@Override
	public Integer addPurchaseDetails(Long phoneNumber, String customerName,
			String emailId, Integer mobileId) throws MobilePurchaseException {
		
		try(
			Connection connection=DBConnection.getConnection();	
			PreparedStatement pst=connection.prepareStatement(QueryMapper.ADD_PURCHASE_DETAILS);
				Statement statement=connection.createStatement();
				){
			pst.setString(1, customerName);
			pst.setString(2, emailId);
			pst.setLong(3, phoneNumber);
			pst.setInt(4, mobileId);
			int n=pst.executeUpdate();
			if(n>0){
				new MobileDaoImpl().updateMobileQuantity(mobileId,1);
				ResultSet resultSet=statement.executeQuery(QueryMapper.PURCHASE_ID);
				while(resultSet.next()){
					Integer id=resultSet.getInt(1);
					return id;
				}
			
			
			
				System.out.println("purchase successfull..");
			}else{
				System.out.println("Failed to purchase..");
			}
		
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
