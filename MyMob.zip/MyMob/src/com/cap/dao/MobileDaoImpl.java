package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cap.bean.Mobile;
import com.cap.exception.MobilePurchaseException;
import com.cap.util.DBConnection;

public class MobileDaoImpl implements IMobileDAO{

	@Override
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException{
		int count=0;
		List<Mobile> mobileList=new ArrayList<>();
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				
				){
			ResultSet resultSet=statement.executeQuery(QueryMapper.RETRIEVE_ALL_MOBILES);
			while(resultSet.next()){
				count++;
				Mobile mobile=new Mobile();
				populate(resultSet,mobile);
				mobileList.add(mobile);
				
				}
			if(count!=0){
				return mobileList;
				
			}else{
				System.out.println("Failed to retrieve mobile data..");
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	}

	private void populate(ResultSet resultSet, Mobile mobile) throws SQLException {
		mobile.setMobileId(resultSet.getInt(1));
		mobile.setName(resultSet.getString(2));
		mobile.setPrice(resultSet.getDouble(3));
		mobile.setQuantity(resultSet.getInt(4));
		
	}

	@Override
	public Boolean isValidMobileId(Integer mobileId)
			throws MobilePurchaseException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(QueryMapper.IS_VALID_MOBILE_ID);
				
				){
			pst.setInt(1, mobileId);
			ResultSet resultSet=pst.executeQuery();
			while(resultSet.next()){
				return true;
			}
			return false;
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	}

	public Integer updateMobileQuantity(Integer mobileId, Integer quantity) throws MobilePurchaseException, SQLException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(QueryMapper.UPDATE_MOBILE_QUANTITY);
				
				){
			pst.setInt(1, quantity);
			pst.setInt(2, mobileId);
			int n=pst.executeUpdate();
			return n;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	
		
		
	}

	public Mobile getMobileId(Integer mobileId) throws MobilePurchaseException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement pst=connection.prepareStatement(QueryMapper.GET_VALID_MOBILE_ID);
				
				){
			pst.setInt(1, mobileId);
			ResultSet resultSet=pst.executeQuery();
			if(resultSet.next()){
				Mobile mobile=new Mobile();
				populate(resultSet, mobile);
				return mobile;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
