package com.cap.dao;

import com.cap.exception.MobilePurchaseException;

public interface IPurchaseDAO {
	public Integer addPurchaseDetails(Long phoneNumber, String customerName,
			String emailId, Integer mobileId) throws MobilePurchaseException;

}
