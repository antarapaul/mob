package com.cap.service;

import java.util.List;

import com.cap.bean.Mobile;
import com.cap.dao.IMobileDAO;
import com.cap.dao.MobileDaoImpl;
import com.cap.exception.MobilePurchaseException;

public class MobileServiceImpl implements IMobileService {
	private IMobileDAO mobileDAO=new MobileDaoImpl();

	@Override
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException {
		
		return mobileDAO.getAllMobileDetails();
	}

	@Override
	public Boolean isValidMobileId(Integer mobileId)
			throws MobilePurchaseException {
		
		return mobileDAO.isValidMobileId(mobileId);
	}

	
}
