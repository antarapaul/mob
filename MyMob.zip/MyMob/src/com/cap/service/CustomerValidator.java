package com.cap.service;

import java.util.regex.Pattern;

public class CustomerValidator {

	public boolean isValidPhoneNumber(Long phoneNumber) {
		String mobile=phoneNumber.toString();
		String regex="^[1-9][0-9]{9}$";
		
		return Pattern.matches(regex, mobile);
	}

	public boolean isValidName(String customerName) {
		String regex="^[A-Z]{1}[a-zA-Z\\s]{0,19}$";
		
		return Pattern.matches(regex, customerName);
	}

	public boolean isValidEmailId(String emailId) {
		String regex="^[a-zA-Z0-9._]+[@][a-zA-Z0-9]+[.][a-zA-Z]{2,3}$";
		return Pattern.matches(regex, emailId);
	}

	/*public boolean isValidMobileId(Integer mobileId) {
		
		return false;
	}*/
	
	

}
