package com.cap.service;

import com.cap.exception.MobilePurchaseException;

public interface IPurchaseService {

	public Integer addPurchaseDetails(Long phoneNumber, String customerName,
			String emailId, Integer mobileId) throws MobilePurchaseException;

	

}
