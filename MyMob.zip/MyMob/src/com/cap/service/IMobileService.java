package com.cap.service;

import java.util.List;

import com.cap.bean.Mobile;
import com.cap.exception.MobilePurchaseException;

public interface IMobileService {
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException;
	public Boolean isValidMobileId(Integer mobileId) throws MobilePurchaseException;
	//public Integer updateMobile(Integer mobileId,Integer quantity) throws MobilePurchaseException;

}
