package com.cap.service;

import com.cap.bean.Mobile;
import com.cap.dao.IPurchaseDAO;
import com.cap.dao.MobileDaoImpl;
import com.cap.dao.PurchaseDaoImpl;
import com.cap.exception.MobilePurchaseException;

public class PurchaseServiceImpl implements IPurchaseService {
	
	private IPurchaseDAO purchaseDao=new PurchaseDaoImpl();

	@Override
	public Integer addPurchaseDetails(Long phoneNumber, String customerName,
			String emailId, Integer mobileId) throws MobilePurchaseException {
		try{
			Mobile mobile=new MobileDaoImpl().getMobileId(mobileId);
			if(mobile.getMobileId()>0){
				Integer purchaseId= purchaseDao.addPurchaseDetails(phoneNumber, customerName, emailId, mobileId);
				return purchaseId;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
		
		
	}

}
