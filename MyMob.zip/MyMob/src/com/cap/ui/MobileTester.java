package com.cap.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.bean.Mobile;
import com.cap.service.CustomerValidator;
import com.cap.service.IMobileService;
import com.cap.service.IPurchaseService;
import com.cap.service.MobileServiceImpl;
import com.cap.service.PurchaseServiceImpl;

public class MobileTester {

	private static Scanner scanner=new Scanner(System.in);
	//private static Mobile mobile=new Mobile();
	private static IMobileService mobileService=new MobileServiceImpl();
	private static IPurchaseService purchaseService=new PurchaseServiceImpl();


	public static void main(String[] args) {
		int option;
		while(true){
			System.out.println();
			System.out.println();
			System.out.println("   Mobile Application System ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Mobile ");
			System.out.println("2.Search Mobile Based On Price Range");
			System.out.println("3.Retrive All Mobile");
			System.out.println("4.Delete Mobile");
			System.out.println("5.Purchase Mobile");
			System.out.println("6.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try{

				option=scanner.nextInt();
				switch(option){
				case 1:
					break;
				case 2:
					break;
				case 3:
					List<Mobile> mobileList=mobileService.getAllMobileDetails();
					Iterator<Mobile> iterator=mobileList.iterator();
					while(iterator.hasNext()){
						System.out.println(iterator.next());
					}
					break;
				case 4:
					break;
				case 5:
					CustomerValidator validator=new CustomerValidator();
					System.out.println("Enter 10digit mobileNo: ");
					Long phoneNumber=scanner.nextLong();

					if(validator.isValidPhoneNumber(phoneNumber)){
						System.out.println("Enter Your Name [Starting with uppercase]: ");
						scanner.nextLine();
						String customerName=scanner.nextLine();

						if(validator.isValidName(customerName)){
							System.out.println("Enter email id: ");
							String emailId=scanner.nextLine();

							if(validator.isValidEmailId(emailId)){
								System.out.println("Enter desired mobile id: ");
								Integer mobileId=scanner.nextInt();
								if(mobileService.isValidMobileId(mobileId)){
									

									Integer purchaseId=purchaseService.addPurchaseDetails(phoneNumber,customerName,emailId,mobileId);

									System.out.println("Order successfully placed with purchaseId: "+purchaseId);
									
								}else{
									System.out.println("enter valid mobileId");
								}




							}else{
								System.out.println("Please enter valid emailId");
							}
						}else{
							System.out.println("Enter valid name");
						}
					}else{
						System.out.println("Enter valid phone number");
					}

					break;
				case 6:
					System.out.print("Exit Mobile Purchase System");
					System.exit(0);
				default:
					System.out.println("Enter a valid option[1-6]");

				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}



	}

}
