package com.capgemini.mps.presentation;

public class MPSMain {

	public static void main(String[] args) {
		

	}

}
