package com.capgemini.mps.service;

import java.util.regex.Pattern;

public class CustomerValidator {
	
	public Boolean isValidCustomerName(String name){
		String regex="^[A-Z]{1}[a-zA-Z\\s]{0,19}$";

		return Pattern.matches(regex, name);
		
	}
	
	/**
	 * 
	 * @param customer
	 * @return true if email is valid else return false.
	 * email validity
	 * 1.begin with digi or alphabate followed by on @ followed by . followed by 2 character
	 */
	public Boolean isValidEmail(String emailId){
		//String regex="^[0-9a-zA-Z]+(\\.)([a-zA-Z])+(\\@)([a-zA-Z])+(\\.)([a-zA-Z]{3})$";
		
		String regex="^[a-zA-Z0-9._]+[@][a-zA-Z0-9]+[.][a-zA-Z]{2,3}$";
	
		return Pattern.matches(regex, emailId);
		
	}
	public Boolean isValidPhoneNumber(Long phoneNumber){
		String mobile=phoneNumber.toString();
		String regex="^[1-9][0-9]{9}$";
		return Pattern.matches(regex, mobile);
		}

}
