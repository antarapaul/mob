package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class CustomerValidatorTest {
	@Ignore
	@Test
	public void testIsValidCustomerName() {
		assertTrue(new CustomerValidator().isValidCustomerName("Ravi Kumar"));
	}
	
	@Ignore
	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new CustomerValidator().isValidCustomerName("Ravi Kumar"));
	}
	
	
	
	@Test
	public void testIsValidEmail() {
		assertTrue(new CustomerValidator().isValidEmail("ravi@123.com"));
	}
	@Ignore
	@Test
	public void testIsNotValidEmail() {
		assertFalse(new CustomerValidator().isValidEmail("ravi@123.com"));
	}
	@Ignore
	@Test
	public void testIsValidPhoneNumber() {
		assertTrue(new CustomerValidator().isValidPhoneNumber(8957490385L));
	}
	
	@Ignore
	@Test
	public void testIsNotValidPhoneNumber() {
		assertFalse(new CustomerValidator().isValidPhoneNumber(8957490385L));
	}

}
