package com.cg.frs.exception;

public class FlatRegException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;
	
	public FlatRegException(){
		super();	
	}

	public FlatRegException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "FlatRegException [message=" + message + "]";
	}
	
	
	
	

}
