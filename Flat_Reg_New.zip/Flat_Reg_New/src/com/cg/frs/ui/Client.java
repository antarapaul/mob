package com.cg.frs.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {

	private static Scanner scanner=new Scanner(System.in);
	private static FlatRegistrationDTO flat=new FlatRegistrationDTO();
	private static IFlatRegistrationService flatService=new FlatRegistrationServiceImpl();




	public static void main(String[] args) {

		int option;
		while(true){
			System.out.println("Welcome to Flat Registration Portal..");
			System.out.println("---------------------------------------");
			System.out.println("1.Book Flat");
			System.out.println("2.Exit");
			System.out.println("Enter your choice[1/2]: ");
			option=scanner.nextInt();
			try{
				switch(option){

				case 1:


					System.out.println("Enter owner Id from above list: "+flatService.getAllOwnerIds());
					System.out.println("Enter owner Id: ");
					Integer owner_id=scanner.nextInt();

					flat.setOwner_id(owner_id);

					System.out.println("select flat type(1-bhk)/(2-bhk): ");
					Integer flat_type=scanner.nextInt();
					flat.setFlat_type(flat_type);

					System.out.println("select flat area: ");
					Integer flat_area=scanner.nextInt();
					flat.setFlat_area(flat_area);

					System.out.println("select desired rent: ");
					Double rent_amount=scanner.nextDouble();
					flat.setRent_amount(rent_amount);

					System.out.println("select desired deposite: ");
					Double deposite_amount=scanner.nextDouble();
					flat.setDeposite_amount(deposite_amount);
					checkRentAmount(owner_id, flat_type, flat_area, rent_amount, deposite_amount);


				break;

				case 2:
					System.exit(0);
					break;
				default:
					System.out.println("Please enter valid options [1-2]");






				}
			}catch(Exception e){
				e.printStackTrace();
			}

		}


	}




	private static void checkRentAmount(Integer owner_id, Integer flat_type,
			Integer flat_area, Double rent_amount, Double deposite_amount) throws FlatRegException {
		
		if(rent_amount<deposite_amount){
			FlatRegistrationDTO registeredFlat=new FlatRegistrationDTO(owner_id,flat_type,flat_area,rent_amount,deposite_amount);
			registeredFlat=flatService.registerFlat(flat);
			long flatRegId=registeredFlat.getFlat_reg_no();
			System.out.println("Flat is booked with booking id:"+flatRegId);
		}else{
			System.out.println("Enter valid credentials..");
		}

	}

}
