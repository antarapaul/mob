package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;


public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	
	private IFlatRegistrationDAO flatDao=new FlatRegistrationDAOImpl();

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat)
			throws FlatRegException {
		if(flatDao.getAllOwnerIds().contains(flat.getOwner_id())){
			if((flat.getFlat_type()==1)||flat.getFlat_type()==2){
				FlatRegistrationDTO flat1= flatDao.registerFlat(flat);
			
			return flat1;
		}else{
			throw new FlatRegException("Enter valid flat type");
		}
		}
	else{
		throw new FlatRegException("Enter valid owner id");
			
		}
	
			
		
		
		
		
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegException{
		
		ArrayList<Integer> list=flatDao.getAllOwnerIds();
		return list;
	}

}
