package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;

public interface IFlatRegistrationService {
	
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws FlatRegException;
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegException;

}
