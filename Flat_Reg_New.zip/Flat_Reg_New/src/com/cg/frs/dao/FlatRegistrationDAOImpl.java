package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;
import com.cg.frs.util.DBConnection;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {
	//private static Logger myMobDAOLogger=Logger.getLogger(FlatRegistrationDAOImpl.class);
/*
 * to register a flat
 * @see com.cg.frs.dao.IFlatRegistrationDAO#registerFalt(com.cg.frs.dto.FlatRegistrationDTO)
 */
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat)
			throws FlatRegException {
		
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = 
						connection.prepareStatement("INSERT into flat_registration VALUES(flat_seq.NEXTVAL,?,?,?,?,?)");
				Statement statement = 
						connection.createStatement();
				){
		
			if(new FlatRegistrationDAOImpl().getAllOwnerIds().contains(flat.getOwner_id())){
			preparedStatement.setInt(1,flat.getOwner_id());
			
			preparedStatement.setInt(2,flat.getFlat_type());
			
			preparedStatement.setInt(3,flat.getFlat_area());
			
			preparedStatement.setDouble(4,flat.getRent_amount());
			
			preparedStatement.setDouble(5,flat.getDeposite_amount());
			
			
			}
			int n=preparedStatement.executeUpdate();
			if(n>0){
				
				ResultSet resultSet = statement.executeQuery("SELECT flat_seq.CURRVAL from dual");
				if(resultSet.next()){
					
					Long id=resultSet.getLong(1);
					flat.setFlat_reg_no(id);
				
					return flat;
				}
			}
			
			
		}catch(FlatRegException e){
			throw new FlatRegException("owner doesnot exists.");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	
	}
	/*
	 *method to get all existing owner ids
	 * @see com.cg.frs.dao.IFlatRegistrationDAO#getOwnerIds()
	 */

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegException {
		ArrayList<Integer> ownerIdList = new ArrayList<>();
		try(
				Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			
			//ResultSet resultSet = statement.executeQuery("SELECT owner_id from flat_owners");
			//while(resultSet.next()){
			//ownerIdList.add(resultSet.getInt(1));
			
				ownerIdList.add(1);
				ownerIdList.add(2);
				ownerIdList.add(3);
			//}
			
			
		}catch(FlatRegException e){
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return ownerIdList;
	}

}
