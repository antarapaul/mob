package com.cg.frs.util;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.cg.frs.exception.FlatRegException;



public class DBConnectionTest {

	@Test
	public void testGetConnection() throws FlatRegException, SQLException {
		assertNotNull(DBConnection.getConnection());
	}

}
