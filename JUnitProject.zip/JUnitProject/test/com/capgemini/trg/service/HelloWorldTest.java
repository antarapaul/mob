package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class HelloWorldTest {
	@BeforeClass
	public static void beforeUnitTest(){
		System.out.println("Initialization common for all test methods");
	}
	
	@AfterClass
	public static void afterUnitTest(){
		System.out.println("Cleanup after excuting all test method");
	}
	
	@Before
	public void beforeTestMethod(){
		System.out.println("The executes before each test method");
	}
	
	@After
	public void afterTestMethod(){
		System.out.println("The executes after each test method");
	}

	@Test
	public void testGetMessage() {
		
		HelloWorld helloWorld=new HelloWorld();
		
		//fail("Not yet implemented");
		assertEquals("Hello World!!",helloWorld.getMessage());
	}
	//@Ignore
	@Test
	public void testMethod(){
		System.out.println("Ignored this method");
		
	}

}
