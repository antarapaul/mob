package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTester {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test//(expected=IllegalArgumentException.class)
	public void testCalculatorDoubleDouble() {
		//fail("Not yet implemented");
		//assertEquals((10),new Calculator(12.00,null));
	}

	@Test//(expected=IllegalArgumentException.class)
	public void testAdd() {
		assertEquals(new Double(30.00),new Calculator().add(20.00,10.00),0.01);
		//fail("Not yet implemented");
	}

	@Test//(expected=IllegalArgumentException.class)
	public void testSub() {
		assertEquals(new Double(10.00),new Calculator().sub(20.00,10.00),0.00);
		//fail("Not yet implemented");
	}

	@Test//(expected=IllegalArgumentException.class)
	public void testMult() {
		assertEquals(new Double(200.00),new Calculator().mult(20.00,10.00),0.01);
		//fail("Not yet implemented");
	}

	@Test//(expected=IllegalArgumentException.class)
	public void testDiv() {
		assertEquals(new Double(2.00),new Calculator().div(20.00,10.00),0.01);
		//fail("Not yet implemented");
	}
	
	/*@Test(expected=IllegalArgumentException.class)
	public void testNotNullFirstNum(){
		assertNotNull(12,new Calculator(12,null));
	}*/
	@Test//(expected=IllegalArgumentException.class)
	public void testFirstNumber(){
		assertEquals(20.0,new Calculator(20.00,null).getNumber1().doubleValue(),0.01);
		
	}
	
	@Test//(expected=IllegalArgumentException.class)
	public void testLastNumber(){
		assertEquals(10.0,new Calculator(null,10.00).getNumber2().doubleValue(),0.01);
		
	}

	//@Test(expected=IllegalArgumentException.class)
	

}
