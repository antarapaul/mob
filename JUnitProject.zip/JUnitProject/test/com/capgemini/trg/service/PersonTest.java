package com.capgemini.trg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Initialize code before all test methods");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Cleanup code after all test methods");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Initialize code before each test methods");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Cleanup code after each test methods");
	}

	@Test(expected=IllegalArgumentException.class)
	public void testPersonForException() {
		//fail("Not yet implemented");
		assertNull(null,new Person(null,null,8000.00));
	}

	@Test
	public void testPersonForNotNull() {
		//fail("Not yet implemented");
		assertNotNull("Ravi",new Person("Ravi",null,8000.00));
	}
	
	@Test
	public void testGetFullName(){
		assertEquals("Ravi Kumar",new Person("Ravi","Kumar",8000.00).getFullName());
	}
	
	@Test
	public void testFirstName(){
		assertEquals("Ravi",new Person(null,"Ravi",8000.00).getFirstName());
		
	}
	
	
	@Test
	public void testLastName(){
		assertEquals("Kumar",new Person("Ravi","Kumar",8000.00).getLastName());
		
	}

}
