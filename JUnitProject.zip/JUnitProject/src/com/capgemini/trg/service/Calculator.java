package com.capgemini.trg.service;

public class Calculator {
	private Double number1;
	private Double number2;


	//private Double calculate();
	public Calculator(){

	}

	public Calculator(Double number1, Double number2) {
		/*if(number1==null && number2==null){
			throw new IllegalArgumentException("Both firstnumber and secondnumber has to be entered");
		}*/
		this.number1 = number1;
		this.number2 = number2;
		//this.choice = choice;
	}

	public Double getNumber1() {
		return number1;
	}
	public void setNumber1(Double number1) {
		this.number1 = number1;
	}
	public Double getNumber2() {
		return number2;
	}
	public void setNumber2(Double number2) {
		this.number2 = number2;
	}

	public Double add(Double number1,Double number2){
		/*if(number1==null && number2==null){
			throw new IllegalArgumentException("Both firstnumber and secondnumber has to be entered");
		}*/
		return number1+number2;
	}

	public Double sub(Double number1,Double number2){
		/*if(number1==null && number2==null){
			throw new IllegalArgumentException("Both firstnumber and secondnumber has to be entered");
		}*/
		return number1-number2;
	}

	public Double mult(Double number1,Double number2){
		/*if(number1==null && number2==null){
			throw new IllegalArgumentException("Both firstnumber and secondnumber has to be entered");
		}*/
		return number1*number2;
	}

	public Double div(Double number1,Double number2){
		/*if(number1==null && number2==null){
			throw new IllegalArgumentException("Both firstnumber and secondnumber has to be entered");
		}else if(number2==0){
			throw new ArithmeticException("Division By Zero");
		}*/

		return number1/number2;


	}



}
